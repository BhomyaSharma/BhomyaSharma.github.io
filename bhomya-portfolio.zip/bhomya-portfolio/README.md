# Bhomya Sharma — Portfolio (GitHub Pages)

This folder is a ready-to-deploy GitHub Pages site.

## Structure
```
index.html                        → main portfolio (hero, projects, experience, skills, education, contact)
paula-chatbot/index.html          → Paula case study page
paula-chatbot/paula-kb-screenshot.jpg → screenshot used in the case study
```

## Deploy to github.io (matches links already in your resume)

Your resume links to `https://bhomyasharma.github.io` and
`https://bhomyasharma.github.io/paula-chatbot/`, which means your GitHub
Pages repo must be named exactly **`bhomyasharma.github.io`**.

1. On GitHub, create (or open) a repo named `bhomyasharma.github.io`
   under your account (`BhomyaSharma`).
2. Upload the contents of this folder to the **root** of that repo
   (not inside a subfolder) — `index.html` goes at the repo root,
   and the `paula-chatbot/` folder goes alongside it.
   - Easiest: drag-and-drop both `index.html` and the `paula-chatbot`
     folder into the GitHub web UI's "Add file → Upload files" screen,
     or push via git:
     ```
     git init
     git add .
     git commit -m "Portfolio site"
     git branch -M main
     git remote add origin https://github.com/BhomyaSharma/bhomyasharma.github.io.git
     git push -u origin main
     ```
3. In the repo, go to **Settings → Pages** and confirm the source is
   set to the `main` branch, root folder. GitHub Pages auto-publishes
   `username.github.io` repos, usually within a minute or two.
4. Visit `https://bhomyasharma.github.io` to confirm the homepage
   loads, and `https://bhomyasharma.github.io/paula-chatbot/` to
   confirm the case study loads.

## Notes on what was updated
- Title/role updated throughout from "AI Product Manager Intern" to
  "Associate Product Manager" (per your promotion in Jun 2026), with
  the internship kept as a second, earlier entry in Experience.
- Projects grid expanded to include the LinkedIn Chrome Extension
  (linked to the Chrome Web Store listing), the Onboarding Module
  (linked to your interactive mockup), CRM & CMP Sync, and the Voice
  of Customer Copilot project — all pulled from your resume.
- The PAULA project card now links directly to `paula-chatbot/index.html`.
- Nav pill and contact section were reworded slightly since the
  original copy said "open to PM roles" — now that you're placed at
  Sprouts.ai, that read as inconsistent with the timeline. Adjust the
  wording back if you'd rather keep an open-to-work framing.

## Not included
- The Onboarding Module interactive mockup itself (referenced by
  link only — you mentioned it's already live at
  `bhomyasharma.github.io/onboarding-mockup/`).
- Your resume as a webpage — only the .docx was provided. Say the
  word if you'd like an HTML/PDF version linked from the site too.
